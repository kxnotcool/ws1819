import HigherOrderScala._
import org.scalatest.FunSuite

class HigherOrderScalaTest extends FunSuite {

  // If you are unfamiliar with implementing unit tests in Scala,
  // the test cases from previous examples can be used as examples

  // --------------------------------------------
  // --- PUT ALL YOUR CHANGES BELOW THIS LINE ---
  // --------------------------------------------

  test("TODO") {
    ???
  }

}
