import definitions.FLAEBase._
import definitions.MFLAEBase._

// --------------------------------------------
// --- PUT ALL YOUR CHANGES BELOW THIS LINE ---
// --------------------------------------------

object PreprocMultiarg {
  def preprocMultiarg(expr: MFLAE): FLAE = ???
}
