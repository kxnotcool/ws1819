import definitions.MFAEBase._

object HigherOrderScala {

  // --------------------------------------------
  // --- PUT ALL YOUR CHANGES BELOW THIS LINE ---
  // --------------------------------------------

  // TODO def ... = ...
  // TODO def ... = ...

}
