package task2_implementing_and_using_extended_F1LAE

import ExtendedF1LAE._

object Fibonacci {

  // --------------------------------------------
  // --- PUT ALL YOUR CHANGES BELOW THIS LINE ---
  // --------------------------------------------

  // Define your function here
  // (the example definition always returns the argument n)
  val fibDefs = Map('fib -> FunDef('fib, 'n, 'n))

}
