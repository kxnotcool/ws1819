object Preprocessor {

  /** BooleanExpression represents the abstract syntax of our language,
    * i.e. the representation a parser would generate by reading the program code.
    * This will be consumed by the interpreter (the eval function) to produce a result BooleanValue. */
  sealed trait BooleanExpression
  case object True extends BooleanExpression
  case object False extends BooleanExpression
  case class Not(expr: BooleanExpression) extends BooleanExpression
  case class And(lhs: BooleanExpression, rhs: BooleanExpression) extends BooleanExpression
  case class Or(lhs: BooleanExpression, rhs: BooleanExpression) extends BooleanExpression
  case class Imp(lhs: BooleanExpression, rhs: BooleanExpression) extends BooleanExpression
  case class BiImp(lhs: BooleanExpression, rhs: BooleanExpression) extends BooleanExpression

  // --------------------------------------------
  // --- PUT ALL YOUR CHANGES BELOW THIS LINE ---
  // --------------------------------------------

  // implement this function
  def preproc(expr: BooleanExpression): BooleanExpression = ???

}
