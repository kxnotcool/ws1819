object ScalaWarmUp {

  // --------------------------------------------
  // --- PUT ALL YOUR CHANGES BELOW THIS LINE ---
  // --------------------------------------------

  def flatten[A](xss : List[List[A]]) : List[A] = ???

  def reverse[A](l: List[A]): List[A] = ???

}